//
//  VideoEducaFinalApp.swift
//  VideoEducaFinal
//
//  Created by User on 14/11/23.
//

import SwiftUI

@main
struct VideoEducaFinalApp: App {
    var body: some Scene {
        WindowGroup {
            TelaDeEntrada()
        }
    }
}
