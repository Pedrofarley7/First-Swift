//
//  EstruturaMat4.swift
//  VideoEducaFinal
//
//  Created by User on 14/11/23.
//

import SwiftUI

struct EstruturaMat4: View {
    var body: some View {
        TabView{
            VideoMat4()
                .tabItem {
                    Image(systemName: "video")
                    Text("Vídeo-Aula")
                }
                .background(Color.white)
            ExerciciosMat4()
                .tabItem {
                    Image(systemName: "book.pages")
                    Text("Exercícios")
                }
                .background(Color.white) // Fundo branco para a ScrollView
                        .ignoresSafeArea(.container, edges: .bottom)
        }
    }
    }

#Preview {
    EstruturaMat4()
}
