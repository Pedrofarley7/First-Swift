//
//  teste3App.swift
//  teste3
//
//  Created by User on 05/12/23.
//

import SwiftUI

@main
struct teste3App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
