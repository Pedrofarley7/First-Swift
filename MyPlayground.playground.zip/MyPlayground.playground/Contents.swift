let mentores = ["Gabi", "Mateus", "Elis", "Carol", "Cáren", "Lucas", "Davi"]

let nomesC = mentores.filter { $0.contains("c")}

print(nomesC)

