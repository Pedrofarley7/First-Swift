//
//  TelaDeExerciciosApp.swift
//  TelaDeExercicios
//
//  Created by User on 08/12/23.
//

import SwiftUI

@main
struct TelaDeExerciciosApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
